var androidgc = require('ti.nartex.androidgc');
androidgc.gc();